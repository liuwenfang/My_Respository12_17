package com.zzx.blog.bean;

/**
 * Created by Administrator on 2018/7/2 0002.
 */

public class SubsidyBean {

    /**
     * ID : 2
     * AppName : 测试
     * AddTime : 2018-10-25 17:18:20
     */

    private int ID;
    private String AppName;
    private String AddTime;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getAppName() {
        return AppName;
    }

    public void setAppName(String AppName) {
        this.AppName = AppName;
    }

    public String getAddTime() {
        return AddTime;
    }

    public void setAddTime(String AddTime) {
        this.AddTime = AddTime;
    }
}
