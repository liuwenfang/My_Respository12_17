package com.zzx.blog.photo;

import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

/**
 * 动画监听
 */
public class SelfAnimationListener implements AnimationListener {

    @Override
    public void onAnimationEnd(Animation arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onAnimationRepeat(Animation arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onAnimationStart(Animation arg0) {
        // TODO Auto-generated method stub

    }

}
