package com.zzx.blog.myinterface;


import com.zzx.blog.bean.CommonBean;

/**
 * Created by zzx on 2017/8/7 0007.
 */
public interface EventInterface {
    public abstract void setEvent(CommonBean enity);
}
