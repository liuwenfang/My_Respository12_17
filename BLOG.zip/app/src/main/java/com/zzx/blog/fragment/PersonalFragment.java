package com.zzx.blog.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zzx.blog.AppContext;
import com.zzx.blog.R;
import com.zzx.blog.activity.MyBlogListActivity;
import com.zzx.blog.activity.MySubsidyActivity;
import com.zzx.blog.activity.PersonalAuthActivity;
import com.zzx.blog.base.BaseFragment;
import com.zzx.blog.bean.CommonBean;
import com.zzx.blog.bean.UserBean;
import com.zzx.blog.myinterface.EventInterface;

import butterknife.BindView;
import butterknife.OnClick;


/**
 * 个人中心
 *
 * @author zzx
 */

public class PersonalFragment extends BaseFragment {


    @BindView(R.id.llQuota)
    LinearLayout llQuota;
    @BindView(R.id.llUser)
    LinearLayout llUser;
    @BindView(R.id.tvLimit)
    TextView tvLimit;
    @BindView(R.id.tvUserName)
    TextView tvUserName;

    private UserBean userBean;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_personal;
    }

    @Override
    public void initBundle(Bundle savedInstanceState) {

    }


    @Override
    public void initView() {
        userBean = AppContext.getInstance().getUserInfo();
        if (userBean.getIssmrz() == 0) { //未认证
            llQuota.setVisibility(View.VISIBLE);
            llUser.setVisibility(View.GONE);
        } else { //已认证  显示姓名和额度
            llQuota.setVisibility(View.GONE);
            llUser.setVisibility(View.VISIBLE);
            tvLimit.setText(userBean.getLimit() + "");//额度
            tvUserName.setText(userBean.getRealName() + "");//人名
        }
    }

    @Override
    public void initLogic() {
        setEventInterface(new EventInterface() {
            @Override
            public void setEvent(CommonBean enity) {
                if (enity.getType().equals("authSuccess")) { //认证成功
                    initView();
                }
            }
        });
    }

    @OnClick({R.id.llQuota, R.id.llUser, R.id.llApplySubsidy, R.id.llMyBlog, R.id.llUseRule, R.id.llLaw})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.llQuota:
                if (userBean.getIssmrz() == 0) { //未认证 无额度
                    startActivity(PersonalAuthActivity.class);
                }
                break;
            case R.id.llUser:
//                llQuota.setVisibility(View.VISIBLE);
//                llUser.setVisibility(View.GONE);
                break;
            case R.id.llApplySubsidy:
                startActivity(MySubsidyActivity.class);
                break;
            case R.id.llMyBlog:
                startActivity(MyBlogListActivity.class);
                break;
            case R.id.llUseRule:
                break;
            case R.id.llLaw:
                break;
        }
    }
}
