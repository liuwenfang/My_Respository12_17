package com.zzx.blog.bean;

public class SubsidyDetailBean {

    /**
     * appname : 测试2
     * loan : 1000
     * interest : 50
     * image : LT_0f153b99-92cd-45f3-b82b-c9d893967d8c.png
     */

    private String appname;
    private int loan;
    private int interest;
    private String image;

    public String getAppname() {
        return appname;
    }

    public void setAppname(String appname) {
        this.appname = appname;
    }

    public int getLoan() {
        return loan;
    }

    public void setLoan(int loan) {
        this.loan = loan;
    }

    public int getInterest() {
        return interest;
    }

    public void setInterest(int interest) {
        this.interest = interest;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
