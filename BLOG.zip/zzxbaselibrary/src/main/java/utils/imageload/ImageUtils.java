package utils.imageload;


import android.widget.ImageView;

public class ImageUtils implements ImageLoader {

    private static ImageLoader imageLoader;
    private static ImageUtils xImage;

    public static void init(ImageLoader loader) {
        imageLoader = loader;
    }

    public static ImageUtils getInstance() {
        if (imageLoader==null){
            throw new NullPointerException("Call XFrame.initXImageLoader(ImageLoader loader) within your Application onCreate() method." +
                    "Or extends XApplication");
        }
        if (xImage == null) {
            xImage = new ImageUtils();
        }
        return xImage;
    }

    @Override
    public void load(ImageView imageView, Object imageUrl) {
        imageLoader.load(imageView, imageUrl);
    }

    @Override
    public void load(ImageView imageView, Object imageUrl, int defaultImage) {
        imageLoader.load(imageView, imageUrl, defaultImage);
    }

    @Override
    public void load(ImageView imageView, Object imageUrl, Object transformation) {
        imageLoader.load(imageView, imageUrl, transformation);
    }
}
